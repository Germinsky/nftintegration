<?php
/**
 * Plugin Name: Daily Vibes Embed
 * Description: Embeds the Daily Vibes Web3 rewards app into WordPress
 * Version: 1.0.0
 * Author: Digital Prophets
 */

// Security: Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class DailyVibesEmbed {
    private $plugin_url;
    
    public function __construct() {
        $this->plugin_url = plugin_dir_url(__FILE__);
        
        // Register shortcode
        add_shortcode('daily_vibes', array($this, 'render_app'));
        
        // Register assets
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
    }
    
    /**
     * Enqueue React app assets
     */
    public function enqueue_assets() {
        // Only load on pages with the shortcode
        global $post;
        if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'daily_vibes')) {
            // Dynamically find the built assets (Vite uses content hashes)
            $assets_dir = plugin_dir_path(__FILE__) . 'dist/assets/';
            $assets_url = $this->plugin_url . 'dist/assets/';
            
            // Find main JavaScript file (pattern: main-[hash].js - this is the entry point)
            $js_files = glob($assets_dir . 'main-*.js');
            if (!empty($js_files)) {
                $js_filename = basename($js_files[0]);
                wp_enqueue_script(
                    'daily-vibes-app',
                    $assets_url . $js_filename,
                    array(),
                    filemtime($js_files[0]), // Use file timestamp for cache busting
                    true
                );
                
                // Add module type attribute
                add_filter('script_loader_tag', function($tag, $handle) use ($js_filename) {
                    if ($handle === 'daily-vibes-app') {
                        $tag = str_replace('<script ', '<script type="module" crossorigin ', $tag);
                    }
                    return $tag;
                }, 10, 2);
            }
            
            // Find CSS file (pattern: en_US-[hash].css - main stylesheet)
            $css_files = glob($assets_dir . 'en_US-*.css');
            if (!empty($css_files)) {
                $css_filename = basename($css_files[0]);
                wp_enqueue_style(
                    'daily-vibes-styles',
                    $assets_url . $css_filename,
                    array(),
                    filemtime($css_files[0])
                );
            }
        }
    }
    
    /**
     * Render the app container
     */
    public function render_app($atts) {
        $attributes = shortcode_atts(array(
            'height' => '800px',
        ), $atts);
        
        ob_start();
        ?>
        <div id="root" style="min-height: <?php echo esc_attr($attributes['height']); ?>; width: 100%;"></div>
        <?php
        return ob_get_clean();
    }
}

// Initialize plugin
new DailyVibesEmbed();
